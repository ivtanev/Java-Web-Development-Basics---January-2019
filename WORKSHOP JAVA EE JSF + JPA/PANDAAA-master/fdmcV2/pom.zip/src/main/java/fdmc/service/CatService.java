package fdmc.service;

import fdmc.domain.models.service.CatServiceModel;

public interface CatService {
    void createCat(CatServiceModel catServiceModel);
}
